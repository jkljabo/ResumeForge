from pathlib import Path


class ResumeWriter:

    def write(
        self,
        markdown: str,
        destination: Path,
    ) -> Path:

        destination.parent.mkdir(
            parents=True,
            exist_ok=True,
        )
        
        destination.write_text(
            markdown,
            encoding="utf-8",
        )

        return destination